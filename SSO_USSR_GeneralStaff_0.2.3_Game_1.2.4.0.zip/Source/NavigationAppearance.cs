using Backend.Managers;
using UnityEngine;
using UnityEngine.UI;

namespace SsoUssr.GeneralStaff
{
    public sealed class NavigationAppearance : MonoBehaviour
    {
        private RectTransform visual;
        private Vector2 visualSize;

        public Image Build(RectTransform source, Sprite star)
        {
            // Retain graphics and size, never a component belonging to a scene
            // that will be destroyed when another navigation section is loaded.
            visualSize = source.rect.size;
            // Copy graphics only. Never copy scene switching listeners, hover
            // handlers or a NavPanelController from the game's button.
            visual = CopyGraphics(source, transform);
            visual.name = "NativeButtonFrame";
            visual.anchorMin = visual.anchorMax = visual.pivot = new Vector2(0.5f, 0.5f);
            visual.anchoredPosition = Vector2.zero;
            visual.localRotation = Quaternion.identity;

            Image hitArea = gameObject.AddComponent<Image>();
            hitArea.color = Color.clear;
            hitArea.raycastTarget = true;
            // Native scenes may bake the globe into a single framed sprite.
            // Cover only the inner disk, preserving the original rim and shadow.
            Image disk = AddGraphic("OliveDisk", 0.70f, PopUpWindowManager.GetCircleSprite(),
                new Color(0.31f, 0.33f, 0.23f));
            AddGraphic("SovietStar", 0.61f, star, Color.white);
            return disk;
        }

        private Image AddGraphic(string name, float fraction, Sprite sprite, Color color)
        {
            GameObject obj = new GameObject(name, typeof(RectTransform), typeof(Image));
            obj.layer = gameObject.layer;
            RectTransform rect = (RectTransform)obj.transform;
            rect.SetParent(transform, false);
            float inset = (1 - fraction) * 0.5f;
            rect.anchorMin = new Vector2(inset, inset);
            rect.anchorMax = new Vector2(1 - inset, 1 - inset);
            rect.offsetMin = rect.offsetMax = Vector2.zero;
            Image image = obj.GetComponent<Image>();
            image.sprite = sprite;
            image.color = color;
            image.preserveAspect = true;
            image.raycastTarget = false;
            return image;
        }

        public void Resize(float width, float height)
        {
            if (visual != null)
            {
                visual.sizeDelta = visualSize;
                visual.localScale = new Vector3(width / Mathf.Max(1, visualSize.x), height / Mathf.Max(1, visualSize.y), 1);
            }
        }

        private static RectTransform CopyGraphics(RectTransform source, Transform parent)
        {
            // Source and its ancestors are strictly read-only. In particular,
            // never insert a backdrop into the game's layout or disable its
            // Image: it may also supply the stencil mask for the entire panel.
            GameObject obj = new GameObject(source.name, typeof(RectTransform));
            obj.layer = parent.gameObject.layer;
            RectTransform rect = (RectTransform)obj.transform;
            rect.SetParent(parent, false);
            rect.anchorMin = source.anchorMin;
            rect.anchorMax = source.anchorMax;
            rect.pivot = source.pivot;
            rect.sizeDelta = source.sizeDelta;
            rect.anchoredPosition3D = source.anchoredPosition3D;
            rect.localRotation = source.localRotation;
            rect.localScale = source.localScale;
            Image image = source.GetComponent<Image>();
            if (image != null) CopyImage(image, obj.AddComponent<Image>());
            foreach (Transform child in source)
            {
                RectTransform childRect = child as RectTransform;
                if (childRect != null)
                    CopyGraphics(childRect, rect).gameObject.SetActive(child.gameObject.activeSelf);
            }
            return rect;
        }

        private static void CopyImage(Image source, Image destination)
        {
            destination.sprite = source.sprite;
            destination.type = source.type;
            destination.color = source.color;
            // Use an independent default UI material. A native material can
            // depend on a stencil mask that is absent in our overlay canvas.
            destination.material = null;
            destination.preserveAspect = source.preserveAspect;
            destination.fillCenter = source.fillCenter;
            destination.fillMethod = source.fillMethod;
            destination.fillOrigin = source.fillOrigin;
            destination.fillAmount = source.fillAmount;
            destination.fillClockwise = source.fillClockwise;
            destination.pixelsPerUnitMultiplier = source.pixelsPerUnitMultiplier;
            destination.useSpriteMesh = source.useSpriteMesh;
            destination.raycastTarget = false;
        }
    }
}
