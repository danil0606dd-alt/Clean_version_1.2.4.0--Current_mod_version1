using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using Backend.Managers;
using Backend.Mod;
using Frontend.InputManagement;
using Frontend.SceneLoadManagement;
using Frontend.UI;
using Frontend.UI.Buttons;
using HarmonyLib;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using Object = UnityEngine.Object;

namespace SsoUssr.GeneralStaff
{
    [ModEntryPoint]
    public static class Mod
    {
        public const string Id = "danil.sso.ussr.generalstaff";
        public const string Title = "Генштаб СССР";
        private static bool patched;

        [ModEntryPoint]
        public static void Load()
        {
            if (patched) return;
            new Harmony(Id).PatchAll(typeof(Mod).Assembly);
            patched = true;
            Debug.Log("[SSO USSR] General Staff prototype 0.2.3 loaded (game 1.2.4.0).");
        }
    }

    // Do not extend the game's buttonsObjects/sceneIds arrays: Repaint assumes
    // every item has an existing scene and a predefined keyboard shortcut.
    [HarmonyPatch(typeof(NavPanelController), "Repaint")]
    internal static class NavigationPatch
    {
        private static void Postfix(NavPanelController __instance,
            GameObject[] ___buttonsObjects, int[] ___sceneIds)
        {
            try
            {
                GeneralStaffUI.Attach(__instance, ___buttonsObjects, ___sceneIds);
            }
            catch (Exception ex) { Debug.LogError("[SSO USSR] Navigation: " + ex); }
        }
    }

    [HarmonyPatch(typeof(HotkeysManager), "get_IfHotKeysBlocked")]
    internal static class HotkeysPatch
    {
        private static void Postfix(ref bool __result)
        {
            // Preserve other windows' blocks; never overwrite the game's shared bool.
            if (GeneralStaffUI.BlockHotkeys) __result = true;
        }
    }

    [HarmonyPatch(typeof(CameraScaleManager), "LateUpdate")]
    internal static class CameraPanPatch
    {
        private static bool Prefix() { return !GeneralStaffUI.IsOpen; }
    }

    [HarmonyPatch(typeof(SceneLoadManager), "LoadScene")]
    internal static class SceneChangePatch
    {
        private static void Prefix(int newScene)
        {
            // LoadScene ignores new requests while it is busy; do the same.
            if (!GeneralStaffUI.EngineLoading) GeneralStaffUI.PrepareSceneChange(newScene);
        }
    }

    [HarmonyPatch(typeof(MessageManager), "DisplayMessage")]
    internal static class SystemMessagePatch
    {
        private static void Prefix() { GeneralStaffUI.CloseCurrent(); }
    }

    [DisallowMultipleComponent]
    public sealed class GeneralStaffUI : MonoBehaviour
    {
        // Both managers store enum values in HashSets. An unused value gives this
        // window its own reversible lock without removing another window's lock.
        private const int LockId = 0x53534F;
        private static GeneralStaffUI current;
        private static readonly FieldInfo loadState = AccessTools.Field(typeof(SceneLoadManager), "state");
        public static bool EngineLoading
        {
            get { return SceneLoadManager.inst != null && loadState != null &&
                Convert.ToInt32(loadState.GetValue(SceneLoadManager.inst)) != 0; }
        }
        private static int suppressHotkeysThroughFrame = -1;
        public static bool IsOpen { get { return current != null && current.open; } }
        public static bool BlockHotkeys
        { get { return IsOpen || Time.frameCount <= suppressHotkeysThroughFrame; } }

        private GameObject[] navigationButtons;
        private RectTransform reference;
        private GameObject root, modal;
        private RectTransform buttonRect, panel, contentRect;
        private RectTransform portraitRect, captionRect;
        private readonly RectTransform[] departmentRects = new RectTransform[3];
        private NativeTooltip launchTooltip;
        private NavigationAppearance navigationAppearance;
        private NavigationBackdrop backdrop;
        private Image backdropImage;
        private bool backdropPending;
        private float backdropExtent, backdropCap;
        private float backdropScreenTop;
        private readonly NavigationClipping navigationClipping = new NavigationClipping();
        private float hudTop, hudRight;
        private Button launchButton;
        private Image launchImage;
        private CanvasGroup launchGroup;
        private readonly NavigationSession navigationSession = new NavigationSession();
        private TMP_FontAsset font;
        private Material fontMaterial;
        private Sprite icon;
        private Texture2D iconTexture;
        private Sprite portrait;
        private Texture2D portraitTexture;
        private bool open, initialized, inputLocked, timeLocked;
        private InputManager lockedInputManager;
        private GlobalTimeManager lockedTimeManager;
        private GameObject previousSelection;
        private static readonly Vector3[] corners = new Vector3[4];
        private ScreenBox[] neighbours;
        private int lastWidth, lastHeight;
        private float scale = 1f;
        private int navigationDiagnosticFrame = -1;

        public static void CloseCurrent()
        {
            if (current != null) current.Close();
        }

        public static void Attach(NavPanelController controller, GameObject[] buttons, int[] sceneIds)
        {
            if (buttons == null || buttons.Length == 0) return;
            if (current == null)
            {
                GameObject host = new GameObject("SSO_USSR_GeneralStaffUI", typeof(RectTransform));
                Object.DontDestroyOnLoad(host);
                current = host.AddComponent<GeneralStaffUI>();
            }
            current.Initialize(controller, buttons, sceneIds);
        }

        public static void PrepareSceneChange(int scene)
        {
            if (current == null || !current.initialized) return;
            current.Close();
            current.navigationSession.BeginTransition(scene);
            current.ReleaseBackdrop();
            current.launchTooltip.BindNavigation(null);
            current.reference = null;
            current.navigationButtons = null;
            current.neighbours = null;
            if (current.launchTooltip != null) current.launchTooltip.Hide();
            current.RefreshButtonState();
            Debug.Log("[SSO USSR] Navigation transition to " + scene +
                ": keep button=" + current.navigationSession.InGameplay + ".");
        }

        private void Initialize(NavPanelController controller, GameObject[] buttons, int[] sceneIds)
        {
            if (buttons == null || buttons.Length == 0) return;
            // Update the scene reference, while the owned canvas, images and
            // button survive. A section change must not destroy/recreate them.
            navigationButtons = buttons;
            neighbours = new ScreenBox[buttons.Length];
            reference = FindDiplomacy(buttons, sceneIds);
            if (reference == null) throw new InvalidOperationException("Diplomacy navigation reference not found.");
            navigationSession.Bind(controller.gameObject.scene.buildIndex, sceneIds);
            backdropPending = true;
            if (initialized)
            {
                launchTooltip.BindNavigation(reference);
                navigationDiagnosticFrame = Time.frameCount + 3;
                RefreshButtonState();
                Debug.Log("[SSO USSR] Existing navigation button rebound in " + controller.gameObject.scene.name + ".");
                return;
            }
            try
            {
                FindFont();
                BuildCanvas();
                BuildButton();
                BuildWindow();
                initialized = true;
                LayoutWindow();
                Canvas.ForceUpdateCanvases();
                UpdateButtonPosition();
                navigationDiagnosticFrame = Time.frameCount + 3;
                Debug.Log("[SSO USSR] Button attached above " + reference.name +
                    " in scene " + controller.gameObject.scene.name + " (persistent overlay).");
            }
            catch
            {
                DisposeUI();
                Object.Destroy(gameObject);
                throw;
            }
        }

        private RectTransform FindDiplomacy(GameObject[] buttons, int[] sceneIds)
        {
            RectTransform top = null;
            float topY = float.NegativeInfinity;
            for (int i = 0; i < buttons.Length; ++i)
            {
                if (buttons[i] == null) continue;
                RectTransform rect = buttons[i].transform as RectTransform;
                if (rect == null) continue;
                if (sceneIds != null && i < sceneIds.Length && LanguageManager.inst != null)
                {
                    string title = LanguageManager.inst["scenesNames", "scene" + sceneIds[i]] ?? "";
                    title = title.ToLowerInvariant();
                    if (title.Contains("диплом") || title.Contains("diplomac")) return rect;
                }
                ScreenBox box = ToScreenBox(rect);
                if (box.Y > topY) { topY = box.Y; top = rect; }
            }
            // In the supplied screenshot Diplomacy is the uppermost navigation item.
            return top;
        }

        private void FindFont()
        {
            Canvas nativeCanvas = reference.GetComponentInParent<Canvas>();
            if (nativeCanvas != null)
            {
                foreach (TMP_Text text in nativeCanvas.rootCanvas.GetComponentsInChildren<TMP_Text>(true))
                {
                    if (text.font == null) continue;
                    font = text.font;
                    fontMaterial = text.fontSharedMaterial;
                    break;
                }
            }
            if (font == null) font = TMP_Settings.defaultFontAsset;
            if (font == null) throw new InvalidOperationException("No game TMP font is available.");
        }

        private void BuildCanvas()
        {
            root = gameObject;
            root.AddComponent<Canvas>();
            root.AddComponent<CanvasScaler>();
            root.AddComponent<GraphicRaycaster>();
            root.layer = 5;
            Canvas canvas = root.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 32000;
            CanvasScaler scaler = root.GetComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ConstantPixelSize;
            scaler.scaleFactor = 1f;
            // Own raycaster keeps the star available to close the section while
            // map input is blocked. Native HUD graphics remain visible.
        }

        private void BuildButton()
        {
            icon = LoadSprite("GeneralStaffIcon.png", out iconTexture, true);
            buttonRect = NewRect("GeneralStaffButton", root.transform);
            buttonRect.anchorMin = buttonRect.anchorMax = Vector2.zero;
            navigationAppearance = buttonRect.gameObject.AddComponent<NavigationAppearance>();
            launchImage = navigationAppearance.Build(reference, icon);
            launchButton = buttonRect.gameObject.AddComponent<AdvancedButton>();
            launchButton.targetGraphic = launchImage;
            launchButton.navigation = new Navigation { mode = Navigation.Mode.None };
            Button nativeButton = reference.GetComponent<Button>();
            if (nativeButton != null) launchButton.colors = nativeButton.colors;
            ColorBlock colors = launchButton.colors;
            colors.disabledColor = colors.normalColor;
            launchButton.colors = colors;
            launchGroup = buttonRect.gameObject.AddComponent<CanvasGroup>();
            // A native SpriteSwap can contain the globe: tint our own disk instead.
            launchButton.transition = Selectable.Transition.ColorTint;
            launchButton.onClick.AddListener(Toggle);
            launchTooltip = buttonRect.gameObject.AddComponent<NativeTooltip>();
            launchTooltip.Text = Mod.Title + " - w";
            launchTooltip.RightSided = false;
            launchTooltip.BindNavigation(reference);
        }

        private void BuildWindow()
        {
            RectTransform blocker = NewRect("GeneralStaffModal", root.transform);
            Stretch(blocker, 0, 0, 0, 0);
            modal = blocker.gameObject;

            panel = NewRect("GeneralStaffWindow", blocker);
            AddImage(panel, new Color(0.24f, 0.26f, 0.19f), true);
            RectTransform border = NewRect("Frame", panel);
            Stretch(border, 3, 3, 3, 3);
            AddImage(border, new Color(0.70f, 0.69f, 0.53f), false);
            RectTransform interior = NewRect("Interior", panel);
            Stretch(interior, 7, 7, 7, 7);
            AddImage(interior, new Color(0.84f, 0.83f, 0.69f), true);
            contentRect = NewRect("Content", panel);
            BuildStaffContent();
            modal.SetActive(false);
        }

        private void BuildStaffContent()
        {
            portrait = LoadSprite("Akhromeev.jpg", out portraitTexture);
            portraitRect = NewRect("AkhromeevPortraitFrame", contentRect);
            AddImage(portraitRect, new Color(0.38f, 0.41f, 0.28f), false);
            RectTransform photoRect = NewRect("AkhromeevPortrait", portraitRect);
            Stretch(photoRect, 4, 4, 4, 4);
            Image photo = AddImage(photoRect, Color.white, false);
            photo.sprite = portrait;
            photo.preserveAspect = true;

            TMP_Text caption = AddText("ChiefOfGeneralStaff", contentRect,
                "Начальник Генерального штаба", 28, new Color(0.24f, 0.26f, 0.19f));
            caption.fontStyle = FontStyles.Bold;
            caption.alignment = TextAlignmentOptions.Center;
            captionRect = caption.rectTransform;

            string[] abbreviations = { "ГОУ", "ГРУ", "ГОМУ" };
            string[] names = {
                "Главное оперативное управление",
                "Главное разведывательное управление",
                "Главное организационно-мобилизационное управление"
            };
            for (int i = 0; i < departmentRects.Length; ++i)
            {
                RectTransform rect = NewRect(abbreviations[i], contentRect);
                departmentRects[i] = rect;
                Image background = AddImage(rect, new Color(0.38f, 0.41f, 0.28f), true);
                Outline outline = rect.gameObject.AddComponent<Outline>();
                outline.effectColor = new Color(0.24f, 0.26f, 0.19f);
                outline.effectDistance = new Vector2(2, -2);
                Button button = rect.gameObject.AddComponent<AdvancedButton>();
                button.targetGraphic = background;
                button.navigation = new Navigation { mode = Navigation.Mode.None };
                // Deliberately no onClick action yet: these are empty departments.
                NativeTooltip tip = rect.gameObject.AddComponent<NativeTooltip>();
                tip.Text = names[i];
                TMP_Text label = AddText("Label", rect, abbreviations[i], 28,
                    new Color(0.96f, 0.93f, 0.76f));
                label.alignment = TextAlignmentOptions.Center;
                Stretch(label.rectTransform, 8, 4, 8, 4);
            }
        }

        private void LateUpdate()
        {
            if (!initialized || root == null) return;
            navigationSession.FinishTransition(EngineLoading);
            if (Screen.width != lastWidth || Screen.height != lastHeight) LayoutWindow();
            RefreshButtonState();
            if (reference != null && navigationButtons != null && !navigationSession.InTransition &&
                navigationDiagnosticFrame >= 0 && Time.frameCount >= navigationDiagnosticFrame)
            {
                navigationDiagnosticFrame = -1;
                LogNavigationState();
            }
        }

        private bool ReferenceReady { get { return reference != null && reference.gameObject.activeInHierarchy; } }
        private bool InputAvailable { get { return InputManager.inst == null || InputManager.inst.CurrentStatus; } }
        private bool CanOpenWindow
        {
            get { return initialized && ReferenceReady && !EngineLoading &&
                navigationSession.CanOpen(InputAvailable, HotkeysManager.IfHotKeysBlocked); }
        }

        private void RefreshButtonState()
        {
            if (!initialized || buttonRect == null) return;
            bool visible = navigationSession.Visible(open, InputAvailable) &&
                (ReferenceReady || navigationSession.InTransition);
            bool interactive = visible && (open || CanOpenWindow);
            buttonRect.gameObject.SetActive(visible);
            launchButton.interactable = interactive;
            launchGroup.blocksRaycasts = interactive;
            launchImage.raycastTarget = interactive;
            if (!interactive && launchTooltip != null) launchTooltip.Hide();
            if (backdrop != null) backdrop.Configure(visible ? backdropExtent : 0, backdropCap);
            navigationClipping.Update(visible && backdrop != null, backdropScreenTop);
        }

        private void BeforeCanvasRender()
        {
            if (!initialized || root == null) return;
            // Apply local-canvas coordinates before graphics are rebuilt, without
            // projecting through the camera. During a load keep the last position.
            if (ReferenceReady && (!navigationSession.InTransition || !navigationSession.HasPlacement))
                UpdateButtonPosition();
            RefreshButtonState();
        }

        private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
        {
            if (mode != LoadSceneMode.Single) return;
            navigationSession.SceneLoaded(scene.buildIndex);
            if (!navigationSession.InGameplay)
            {
                Close();
                ReleaseBackdrop();
                if (launchTooltip != null) launchTooltip.BindNavigation(null);
                reference = null;
                navigationButtons = null;
                neighbours = null;
            }
            RefreshButtonState();
        }

        private void Update()
        {
            if (!initialized || current != this || Keyboard.current == null) return;
            Keyboard keyboard = Keyboard.current;
            if (open && keyboard.escapeKey.wasPressedThisFrame) { Close(); return; }
            if (!keyboard.wKey.wasPressedThisFrame || keyboard.ctrlKey.isPressed ||
                keyboard.altKey.isPressed || keyboard.leftMetaKey.isPressed || keyboard.rightMetaKey.isPressed ||
                IsEditingText()) return;
            if (open) { Close(); return; }
            if (CanOpenWindow) Open();
        }

        private static bool IsEditingText()
        {
            GameObject selected = EventSystem.current != null ? EventSystem.current.currentSelectedGameObject : null;
            return selected != null && (selected.GetComponentInParent<TMP_InputField>() != null ||
                selected.GetComponentInParent<InputField>() != null);
        }

        private void UpdateButtonPosition()
        {
            if (reference == null || navigationButtons == null || neighbours == null) return;
            ScreenBox source = ToScreenBox(reference);
            if (source.Width < 1 || source.Height < 1) return;
            for (int i = 0; i < navigationButtons.Length; ++i)
                neighbours[i] = navigationButtons[i] != null
                    ? ToScreenBox(navigationButtons[i].transform as RectTransform) : source;
            ScreenBox position = Placement.Above(source, neighbours);
            buttonRect.anchoredPosition = new Vector2(position.X, position.Y);
            buttonRect.sizeDelta = new Vector2(position.Width, position.Height);
            if (navigationAppearance != null) navigationAppearance.Resize(position.Width, position.Height);
            if (backdropPending)
            {
                backdropPending = false;
                BindBackdrop();
            }
            UpdateBackdrop(source, position);
            UpdateHudInsets(source);
            navigationSession.Placed();
        }

        private void BindBackdrop()
        {
            ScreenBox button = ToScreenBox(reference);
            // The native narrow ancestor is the strip itself. Its Image and
            // mask stay enabled; no object is inserted into its LayoutGroup.
            for (Transform parent = reference.parent; parent != null; parent = parent.parent)
            {
                Image candidate = parent.GetComponent<Image>();
                if (candidate == null || !candidate.enabled || candidate.sprite == null) continue;
                ScreenBox box = ToScreenBox(candidate.rectTransform);
                if (box.Width < button.Width || box.Width > button.Width * 3 ||
                    box.Height < button.Height * 4) continue;
                if (backdrop != null && backdropImage == candidate) return;
                ReleaseBackdrop();
                backdropImage = candidate;
                backdrop = candidate.GetComponent<NavigationBackdrop>();
                if (backdrop == null) backdrop = candidate.gameObject.AddComponent<NavigationBackdrop>();
                backdrop.enabled = true;
                navigationClipping.Bind(candidate);
                Debug.Log("[SSO USSR] Decorative strip bound: " + candidate.name + ", " + Describe(box) + ".");
                return;
            }
            ReleaseBackdrop();
            Debug.LogWarning("[SSO USSR] No narrow navigation backdrop found; native graphics retained.");
        }

        private void UpdateBackdrop(ScreenBox source, ScreenBox position)
        {
            if (backdrop == null || backdropImage == null) return;
            ScreenBox box = ToScreenBox(backdropImage.rectTransform);
            if (box.Height < 1) return;
            float localPerPixel = backdropImage.rectTransform.rect.height / box.Height;
            backdropExtent = Mathf.Max(0, position.Y - source.Y) * localPerPixel;
            backdropScreenTop = box.Y + box.Height * 0.5f + Mathf.Max(0, position.Y - source.Y);
            // Preserve both ornamental caps; only the straight middle grows.
            backdropCap = source.Height * 2 * localPerPixel;
        }

        private void ReleaseBackdrop()
        {
            navigationClipping.Restore();
            if (backdrop != null)
            {
                backdrop.Configure(0, 0);
                // Reuse if Repaint runs again before the old scene is unloaded.
                // Disabling our effect restores the native mesh immediately.
                backdrop.enabled = false;
            }
            backdrop = null;
            backdropImage = null;
            backdropExtent = backdropCap = 0;
            backdropScreenTop = 0;
        }

        private void UpdateHudInsets(ScreenBox source)
        {
            // The supplied 1.2.4.0 HUD reaches 128 px below the top at 1080p.
            // Derive its scale from the native button, including UI scaling.
            float uiScale = source.Height / 44f;
            float top = Mathf.Min(Screen.height * 0.3f, 136 * uiScale);
            float edge = source.X - source.Width * 0.5f - 20 * uiScale;
            if (backdropImage != null)
            {
                ScreenBox strip = ToScreenBox(backdropImage.rectTransform);
                edge = Mathf.Min(edge, strip.X - strip.Width * 0.5f - 6 * uiScale);
            }
            float right = Mathf.Clamp(Screen.width - edge, 64 * uiScale, Screen.width * 0.2f);
            if (Mathf.Abs(hudTop - top) < 0.1f && Mathf.Abs(hudRight - right) < 0.1f) return;
            hudTop = top;
            hudRight = right;
            LayoutWindow();
        }

        private void LogNavigationState()
        {
            // One read-only snapshot after Unity has finished its initial layout.
            // This distinguishes an off-screen panel from a masking/visibility issue.
            Debug.Log("[SSO USSR] Navigation diagnostics: screen=" + Screen.width + "x" + Screen.height +
                ", input=" + (InputManager.inst == null || InputManager.inst.CurrentStatus) + ", open=" + open);
            for (int i = 0; i < navigationButtons.Length; ++i)
            {
                GameObject item = navigationButtons[i];
                if (item == null) continue;
                ScreenBox box = ToScreenBox(item.transform as RectTransform);
                bool inView = box.X + box.Width * 0.5f > 0 && box.X - box.Width * 0.5f < Screen.width &&
                    box.Y + box.Height * 0.5f > 0 && box.Y - box.Height * 0.5f < Screen.height;
                Image graphic = item.GetComponent<Image>();
                Debug.Log("[SSO USSR] Native button " + i + " " + item.name +
                    ": active=" + item.activeInHierarchy + ", image=" + (graphic != null && graphic.enabled) +
                    ", bounds=" + Describe(box) + ", inView=" + inView);
            }
            for (Transform parent = reference.parent; parent != null; parent = parent.parent)
            {
                Image graphic = parent.GetComponent<Image>();
                Mask mask = parent.GetComponent<Mask>();
                LayoutGroup layout = parent.GetComponent<LayoutGroup>();
                CanvasGroup group = parent.GetComponent<CanvasGroup>();
                Debug.Log("[SSO USSR] Navigation ancestor " + parent.name +
                    ": active=" + parent.gameObject.activeInHierarchy + ", children=" + parent.childCount +
                    ", image=" + (graphic != null ? graphic.enabled.ToString() : "none") +
                    ", mask=" + (mask != null && mask.enabled) +
                    ", layout=" + (layout != null ? layout.GetType().Name : "none") +
                    ", alpha=" + (group != null ? group.alpha.ToString("0.###") : "inherited"));
            }
        }

        private static string Describe(ScreenBox box)
        {
            return string.Format(System.Globalization.CultureInfo.InvariantCulture,
                "({0:0.#},{1:0.#};{2:0.#}x{3:0.#})", box.X, box.Y, box.Width, box.Height);
        }

        public static ScreenBox ToScreenBox(RectTransform rect)
        {
            if (rect == null) return new ScreenBox();
            Canvas canvas = rect.GetComponentInParent<Canvas>();
            Canvas rootCanvas = canvas != null ? canvas.rootCanvas : null;
            RectTransform canvasRect = rootCanvas != null ? rootCanvas.transform as RectTransform : null;
            bool screenSpace = rootCanvas != null && rootCanvas.renderMode != RenderMode.WorldSpace;
            Camera camera = !screenSpace && rootCanvas != null ? rootCanvas.worldCamera : null;
            rect.GetWorldCorners(corners);
            Vector2 min = new Vector2(float.MaxValue, float.MaxValue);
            Vector2 max = new Vector2(float.MinValue, float.MinValue);
            foreach (Vector3 corner in corners)
            {
                Vector2 point = screenSpace && canvasRect != null
                    ? (Vector2)canvasRect.InverseTransformPoint(corner)
                    : RectTransformUtility.WorldToScreenPoint(camera, corner);
                min = Vector2.Min(min, point);
                max = Vector2.Max(max, point);
            }
            ScreenBox bounds = new ScreenBox((min.x + max.x) * 0.5f, (min.y + max.y) * 0.5f, max.x - min.x, max.y - min.y);
            if (!screenSpace || canvasRect == null) return bounds;
            Rect local = canvasRect.rect;
            Rect pixels = rootCanvas.pixelRect;
            ScreenBox projected;
            return Placement.TryCanvasToScreen(bounds,
                new ScreenBox(local.center.x, local.center.y, local.width, local.height),
                new ScreenBox(pixels.center.x, pixels.center.y, pixels.width, pixels.height), out projected)
                ? projected : new ScreenBox();
        }

        private void LayoutWindow()
        {
            lastWidth = Screen.width; lastHeight = Screen.height;
            scale = Mathf.Max(0.1f, Mathf.Min(lastWidth / 1920f, lastHeight / 1080f));
            Stretch(panel, 0, hudTop > 0 ? hudTop : 136 * scale,
                hudRight > 0 ? hudRight : 80 * scale, 0);
            Stretch(contentRect, 24 * scale, 18 * scale, 24 * scale, 24 * scale);
            float photoHeight = 300 * scale;
            float photoWidth = photoHeight * portraitTexture.width / portraitTexture.height;
            SetTopCentered(portraitRect, 0, 18 * scale, photoWidth + 8, photoHeight + 8);
            SetTopCentered(captionRect, 0, 346 * scale, 800 * scale, 44 * scale);
            captionRect.GetComponent<TMP_Text>().fontSize = 28 * scale;
            for (int i = 0; i < departmentRects.Length; ++i)
            {
                SetTopCentered(departmentRects[i], (i - 1) * 254 * scale, 422 * scale, 230 * scale, 58 * scale);
                departmentRects[i].GetComponentInChildren<TMP_Text>().fontSize = 28 * scale;
            }
        }

        private static void SetTopCentered(RectTransform rect, float x, float top, float width, float height)
        {
            rect.anchorMin = rect.anchorMax = new Vector2(0.5f, 1);
            rect.pivot = new Vector2(0.5f, 1);
            rect.anchoredPosition = new Vector2(x, -top);
            rect.sizeDelta = new Vector2(width, height);
        }

        private void Toggle()
        {
            if (open) Close(); else Open();
        }

        private void Open()
        {
            if (open || !CanOpenWindow) return;
            try
            {
                open = true;
                if (launchTooltip != null) launchTooltip.Hide();
                previousSelection = EventSystem.current != null ? EventSystem.current.currentSelectedGameObject : null;
                lockedTimeManager = GlobalTimeManager.inst;
                if (lockedTimeManager != null)
                {
                    timeLocked = true;
                    lockedTimeManager.AddProhibition((GlobalTimeManager.TimeFlowProhibition)LockId);
                }
                lockedInputManager = InputManager.inst;
                if (lockedInputManager != null)
                {
                    inputLocked = true;
                    lockedInputManager.AddProhibition((InputProhibitionType)LockId);
                }
                modal.SetActive(true);
                modal.transform.SetAsLastSibling();
                buttonRect.SetAsLastSibling();
                RefreshButtonState();
                if (EventSystem.current != null) EventSystem.current.SetSelectedGameObject(null);
                Debug.Log("[SSO USSR] General Staff window opened.");
            }
            catch (Exception ex)
            {
                Debug.LogError("[SSO USSR] Open window: " + ex);
                Close();
            }
        }

        public void Close()
        {
            if (!open && !inputLocked && !timeLocked) return;
            open = false;
            suppressHotkeysThroughFrame = Time.frameCount + 1;
            if (modal != null) modal.SetActive(false);
            try
            {
                if (inputLocked && lockedInputManager != null)
                    lockedInputManager.RemoveProhibition((InputProhibitionType)LockId);
            }
            catch (Exception ex) { Debug.LogError("[SSO USSR] Release input: " + ex); }
            finally { inputLocked = false; lockedInputManager = null; }
            try
            {
                if (timeLocked && lockedTimeManager != null)
                    lockedTimeManager.RemoveProhibition((GlobalTimeManager.TimeFlowProhibition)LockId);
            }
            catch (Exception ex) { Debug.LogError("[SSO USSR] Release time: " + ex); }
            finally { timeLocked = false; lockedTimeManager = null; }
            if (EventSystem.current != null)
                EventSystem.current.SetSelectedGameObject(previousSelection != null && previousSelection.activeInHierarchy
                    ? previousSelection : null);
            previousSelection = null;
            RefreshButtonState();
        }

        private void OnEnable()
        {
            Canvas.preWillRenderCanvases += BeforeCanvasRender;
            SceneManager.sceneLoaded += OnSceneLoaded;
        }
        private void OnDisable()
        {
            Canvas.preWillRenderCanvases -= BeforeCanvasRender;
            SceneManager.sceneLoaded -= OnSceneLoaded;
            Close();
            ReleaseBackdrop();
            if (buttonRect != null) buttonRect.gameObject.SetActive(false);
        }
        private void OnDestroy() { DisposeUI(); }
        private void DisposeUI()
        {
            Close();
            ReleaseBackdrop();
            if (icon != null) Object.Destroy(icon);
            if (iconTexture != null) Object.Destroy(iconTexture);
            if (portrait != null) Object.Destroy(portrait);
            if (portraitTexture != null) Object.Destroy(portraitTexture);
            root = null; icon = null; iconTexture = null;
            portrait = null; portraitTexture = null;
            initialized = false;
            if (current == this) current = null;
        }

        private static RectTransform NewRect(string name, Transform parent)
        {
            GameObject obj = new GameObject(name, typeof(RectTransform));
            obj.layer = 5;
            RectTransform rect = (RectTransform)obj.transform;
            rect.SetParent(parent, false);
            rect.anchorMin = rect.anchorMax = rect.pivot = new Vector2(0.5f, 0.5f);
            rect.localScale = Vector3.one;
            return rect;
        }

        private static Sprite LoadSprite(string resource, out Texture2D texture, bool mipmaps = false)
        {
            texture = new Texture2D(2, 2, TextureFormat.RGBA32, mipmaps);
            using (Stream stream = typeof(Mod).Assembly.GetManifestResourceStream(resource))
            {
                if (stream == null) throw new InvalidOperationException("Embedded image is missing: " + resource);
                using (MemoryStream data = new MemoryStream())
                {
                    stream.CopyTo(data);
                    if (!ImageConversion.LoadImage(texture, data.ToArray()))
                        throw new InvalidOperationException("Cannot load embedded image: " + resource);
                }
            }
            if (mipmaps) texture.Apply(true, false);
            texture.filterMode = mipmaps ? FilterMode.Trilinear : FilterMode.Bilinear;
            texture.wrapMode = TextureWrapMode.Clamp;
            return Sprite.Create(texture, new Rect(0, 0, texture.width, texture.height), new Vector2(0.5f, 0.5f), 100f);
        }

        private static Image AddImage(RectTransform rect, Color color, bool raycast)
        {
            Image image = rect.gameObject.AddComponent<Image>();
            image.color = color; image.raycastTarget = raycast;
            return image;
        }

        private TMP_Text AddText(string name, Transform parent, string value, float size, Color color)
        {
            TextMeshProUGUI text = NewRect(name, parent).gameObject.AddComponent<TextMeshProUGUI>();
            text.font = font;
            if (fontMaterial != null) text.fontSharedMaterial = fontMaterial;
            text.text = value; text.fontSize = size; text.color = color;
            text.raycastTarget = false; text.enableWordWrapping = false;
            return text;
        }

        private static void Stretch(RectTransform rect, float left, float top, float right, float bottom)
        {
            rect.anchorMin = Vector2.zero; rect.anchorMax = Vector2.one;
            rect.offsetMin = new Vector2(left, bottom);
            rect.offsetMax = new Vector2(-right, -top);
        }
    }

}
