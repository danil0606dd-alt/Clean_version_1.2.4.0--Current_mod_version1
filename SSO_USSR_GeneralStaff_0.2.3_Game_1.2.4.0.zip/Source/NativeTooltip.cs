using Backend.Managers;
using Frontend.ButtonActions;
using HarmonyLib;
using UnityEngine;
using UnityEngine.EventSystems;

namespace SsoUssr.GeneralStaff
{
    // Exactly the same Show(text, empty title, owner) path used by navigation.
    public sealed class NativeTooltip : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
    {
        public string Text;
        public bool RightSided = true;
        private bool navigationTip;
        private RectTransform reference;
        private Transform nativeAnchor;
        private static NativeTooltip active;
        private GameObject overlay;
        private RectTransform nativeWindow, nativeCanvas, surface;
        private Transform oldParent;
        private int oldSibling;
        private Vector2 oldAnchorMin, oldAnchorMax, oldPivot, oldSize;
        private Vector3 oldPosition, oldScale;
        private Quaternion oldRotation;
        private CanvasGroup nativeGroup, mirrorGroup;

        public void BindNavigation(RectTransform button)
        {
            navigationTip = true;
            reference = button;
            nativeAnchor = null;
            if (button == null) return;
            SimplePopUpShowerWithUpdate native = button.GetComponent<SimplePopUpShowerWithUpdate>();
            if (native == null) return;
            var anchorField = AccessTools.Field(typeof(SimplePopUpShowerWithUpdate), "popUpPlace");
            GameObject place = anchorField != null ? anchorField.GetValue(native) as GameObject : null;
            nativeAnchor = place != null ? place.transform : null;
            var sideField = AccessTools.Field(typeof(SimplePopUpShowerWithUpdate), "rightSided");
            if (sideField != null) RightSided = (bool)sideField.GetValue(native);
        }

        private Vector3? NavigationWorldAnchor(PopUpWindowManager manager)
        {
            if (!navigationTip || reference == null || Camera.main == null) return null;
            ScreenBox own = GeneralStaffUI.ToScreenBox(transform as RectTransform);
            ScreenBox source = GeneralStaffUI.ToScreenBox(reference);
            Vector2 screen;
            if (nativeAnchor != null)
            {
                screen = ScreenPoint(nativeAnchor);
                // Per-button anchors follow the new slot. A shared fixed anchor
                // keeps the exact coordinates used by the rest of the panel.
                if (nativeAnchor.IsChildOf(reference))
                    screen += new Vector2(own.X - source.X, own.Y - source.Y);
            }
            else
            {
                // A prefab without popUpPlace still gets a fixed edge and gap,
                // accounting for the native no-title frame's 50-unit offset.
                RectTransform canvas = AccessTools.Field(typeof(PopUpWindowManager), "canvas")
                    .GetValue(manager) as RectTransform;
                float xScale = canvas != null ? Screen.width / Mathf.Max(1, canvas.rect.width) : 1;
                float yScale = canvas != null ? Screen.height / Mathf.Max(1, canvas.rect.height) : 1;
                float uiScale = source.Height / 44f;
                float side = RightSided ? 1 : -1;
                screen = new Vector2(own.X + side * (own.Width * 0.5f + 8 * uiScale + 50 * xScale),
                    own.Y + own.Height * 0.5f - 5 * uiScale - 50 * yScale);
            }
            // Show immediately projects through Camera.main. Converting back
            // with that same camera cancels map pan/zoom, including perspective.
            Camera camera = Camera.main;
            return camera.ScreenToWorldPoint(new Vector3(screen.x, screen.y, camera.nearClipPlane + 1));
        }

        private static Vector2 ScreenPoint(Transform point)
        {
            Canvas canvas = point.GetComponentInParent<Canvas>();
            Canvas root = canvas != null ? canvas.rootCanvas : null;
            RectTransform rect = root != null ? root.transform as RectTransform : null;
            if (root == null || rect == null || root.renderMode == RenderMode.WorldSpace)
                return RectTransformUtility.WorldToScreenPoint(root != null ? root.worldCamera : null, point.position);
            Vector3 local = rect.InverseTransformPoint(point.position);
            Rect bounds = rect.rect, pixels = root.pixelRect;
            return new Vector2(pixels.xMin + (local.x - bounds.xMin) * pixels.width / Mathf.Max(1, bounds.width),
                pixels.yMin + (local.y - bounds.yMin) * pixels.height / Mathf.Max(1, bounds.height));
        }

        public void OnPointerEnter(PointerEventData eventData)
        {
            PopUpWindowManager manager = PopUpWindowManager.inst;
            if (manager == null || string.IsNullOrEmpty(Text)) return;
            if (active != null && active != this) active.Hide();
            active = this;
            // The modal is a screen overlay. Keep the game's own tooltip above
            // it even if the native tooltip canvas normally uses a camera.
            if (GeneralStaffUI.IsOpen) LiftCanvas(manager);
            manager.Show(Text, string.Empty, this, NavigationWorldAnchor(manager), RightSided, false);
        }

        public void OnPointerExit(PointerEventData eventData) { Hide(); }

        private void LiftCanvas(PopUpWindowManager manager)
        {
            if (overlay != null) return;
            nativeCanvas = AccessTools.Field(typeof(PopUpWindowManager), "canvas").GetValue(manager) as RectTransform;
            nativeWindow = AccessTools.Field(typeof(PopUpWindowManager), "mainWindow").GetValue(manager) as RectTransform;
            if (nativeCanvas == null || nativeWindow == null) return;
            // Move only the native tooltip, never the shared HUD or its canvas.
            // The manager continues to update its original text, frame and layout.
            oldParent = nativeWindow.parent;
            oldSibling = nativeWindow.GetSiblingIndex();
            oldAnchorMin = nativeWindow.anchorMin;
            oldAnchorMax = nativeWindow.anchorMax;
            oldPivot = nativeWindow.pivot;
            oldSize = nativeWindow.sizeDelta;
            oldPosition = nativeWindow.anchoredPosition3D;
            oldScale = nativeWindow.localScale;
            oldRotation = nativeWindow.localRotation;
            overlay = new GameObject("SSO_NativeTooltipOverlay", typeof(RectTransform), typeof(Canvas));
            overlay.layer = 5;
            Canvas canvas = overlay.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 32010;
            GameObject obj = new GameObject("NativeCoordinates", typeof(RectTransform));
            obj.layer = 5;
            surface = (RectTransform)obj.transform;
            surface.SetParent(overlay.transform, false);
            surface.anchorMin = surface.anchorMax = new Vector2(0.5f, 0.5f);
            surface.pivot = nativeCanvas.pivot;
            SyncSurface();
            nativeGroup = AccessTools.Field(typeof(PopUpWindowManager), "group").GetValue(manager) as CanvasGroup;
            if (nativeGroup != null && !nativeGroup.transform.IsChildOf(nativeWindow))
                mirrorGroup = overlay.AddComponent<CanvasGroup>();
            nativeWindow.SetParent(surface, false);
            RestoreRect();
            Canvas.ForceUpdateCanvases();
        }

        private void SyncSurface()
        {
            if (surface == null || nativeCanvas == null) return;
            Vector2 size = nativeCanvas.rect.size;
            surface.sizeDelta = size;
            surface.anchoredPosition = Vector2.zero;
            surface.localScale = new Vector3(Screen.width / Mathf.Max(1, size.x), Screen.height / Mathf.Max(1, size.y), 1);
            if (mirrorGroup != null && nativeGroup != null) mirrorGroup.alpha = nativeGroup.alpha;
        }

        private void RestoreRect()
        {
            nativeWindow.anchorMin = oldAnchorMin;
            nativeWindow.anchorMax = oldAnchorMax;
            nativeWindow.pivot = oldPivot;
            nativeWindow.sizeDelta = oldSize;
            nativeWindow.anchoredPosition3D = oldPosition;
            nativeWindow.localScale = oldScale;
            nativeWindow.localRotation = oldRotation;
        }

        public void Hide()
        {
            if (PopUpWindowManager.inst != null) PopUpWindowManager.inst.Hide(this);
            RestoreCanvas();
            if (active == this) active = null;
        }

        private void RestoreCanvas()
        {
            if (overlay == null) return;
            if (nativeWindow != null && oldParent != null)
            {
                nativeWindow.SetParent(oldParent, false);
                nativeWindow.SetSiblingIndex(oldSibling);
                RestoreRect();
            }
            Object.Destroy(overlay);
            overlay = null;
            nativeWindow = null;
            surface = null;
            nativeCanvas = null;
            nativeGroup = mirrorGroup = null;
        }

        private void Update()
        {
            if (overlay != null && (PopUpWindowManager.inst == null ||
                PopUpWindowManager.inst.Owner != this))
            {
                RestoreCanvas();
                if (active == this) active = null;
            }
        }

        private void LateUpdate() { SyncSurface(); }

        private void OnDisable() { Hide(); }
        private void OnDestroy() { Hide(); }
    }
}
