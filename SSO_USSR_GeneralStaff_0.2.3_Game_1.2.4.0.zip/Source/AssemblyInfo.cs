using System.Reflection;
using System.Runtime.Versioning;

[assembly: AssemblyTitle("SSO USSR General Staff")]
[assembly: AssemblyDescription("General Staff UI prototype for Crisis in the Kremlin The Cold War 1.2.4.0")]
[assembly: AssemblyVersion("0.2.3.0")]
[assembly: AssemblyFileVersion("0.2.3.0")]
[assembly: TargetFramework(".NETFramework,Version=v4.8", FrameworkDisplayName = ".NET Framework 4.8")]
