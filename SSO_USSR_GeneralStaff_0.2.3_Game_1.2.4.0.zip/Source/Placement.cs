using System;

namespace SsoUssr.GeneralStaff
{
    // Screen coordinates, origin at bottom left. This also works with the game's camera zoom.
    public struct ScreenBox
    {
        public float X, Y, Width, Height;
        public ScreenBox(float x, float y, float width, float height)
        { X = x; Y = y; Width = width; Height = height; }
    }

    public static class Placement
    {
        // Local coordinates of a screen-space canvas are independent of the
        // map camera. Never project them with Camera.WorldToScreenPoint.
        public static bool TryCanvasToScreen(ScreenBox element, ScreenBox canvas, ScreenBox viewport, out ScreenBox result)
        {
            result = new ScreenBox();
            if (!Valid(element) || !Valid(canvas) || !Valid(viewport)) return false;
            float xScale = viewport.Width / canvas.Width;
            float yScale = viewport.Height / canvas.Height;
            result = new ScreenBox(viewport.X + (element.X - canvas.X) * xScale,
                viewport.Y + (element.Y - canvas.Y) * yScale, element.Width * xScale, element.Height * yScale);
            return Valid(result);
        }

        private static bool Valid(ScreenBox box)
        {
            return Finite(box.X) && Finite(box.Y) && Finite(box.Width) && Finite(box.Height) &&
                box.Width > 0 && box.Height > 0;
        }

        private static bool Finite(float value) { return !float.IsNaN(value) && !float.IsInfinity(value); }

        public static ScreenBox Above(ScreenBox reference, ScreenBox[] neighbours)
        {
            float step = float.MaxValue;
            foreach (ScreenBox other in neighbours)
            {
                float delta = reference.Y - other.Y;
                if (delta > reference.Height * 0.5f &&
                    Math.Abs(reference.X - other.X) <= Math.Max(reference.Width, other.Width) * 0.6f)
                    step = Math.Min(step, delta);
            }
            if (step == float.MaxValue || step > reference.Height * 2.5f)
                step = reference.Height * 1.25f;
            step = Math.Max(step, reference.Height * 1.08f);
            return new ScreenBox(reference.X, reference.Y + step, reference.Width, reference.Height);
        }
    }
}
