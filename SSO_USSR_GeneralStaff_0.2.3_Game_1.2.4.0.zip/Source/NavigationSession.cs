using System.Collections.Generic;

namespace SsoUssr.GeneralStaff
{
    // Engine-independent policy: showing the button and accepting a click are
    // different decisions. A loading frame keeps the last valid placement.
    public sealed class NavigationSession
    {
        private readonly HashSet<int> navigationScenes = new HashSet<int>();
        private int boundScene = -1;
        public bool InGameplay { get; private set; }
        public bool InTransition { get; private set; }
        public bool HasBinding { get; private set; }
        public bool HasPlacement { get; private set; }

        public void Bind(int scene, int[] destinations)
        {
            navigationScenes.Add(scene);
            if (destinations != null)
                foreach (int destination in destinations) navigationScenes.Add(destination);
            boundScene = scene;
            InGameplay = HasBinding = true;
        }

        public void Placed() { HasPlacement = true; }

        public void BeginTransition(int destination)
        {
            InGameplay = navigationScenes.Contains(destination);
            InTransition = true;
            HasBinding = false;
            boundScene = -1;
        }

        public void SceneLoaded(int scene)
        {
            InGameplay = navigationScenes.Contains(scene);
            HasBinding = InGameplay && boundScene == scene;
            if (InGameplay && !HasBinding) InTransition = true;
        }

        public void FinishTransition(bool engineLoading)
        {
            if (!engineLoading && (!InGameplay || HasBinding)) InTransition = false;
        }

        public bool Visible(bool windowOpen, bool inputAvailable)
        {
            return InGameplay && HasPlacement && (windowOpen || InTransition || inputAvailable);
        }

        public bool CanOpen(bool inputAvailable, bool hotkeysBlocked)
        {
            return InGameplay && HasBinding && HasPlacement && !InTransition && inputAvailable && !hotkeysBlocked;
        }
    }
}
