using System;
using System.Collections.Generic;
using SsoUssr.GeneralStaff;
using UnityEngine;
using UnityEngine.UI;

internal static class BackdropTests
{
    private static int checks;
    private static void Check(bool value, string label)
    { if (!value) throw new Exception(label); ++checks; }
    private static void Near(float a, float b, string label)
    { Check(Math.Abs(a-b)<0.01f, label + ": " + a + " != " + b); }

    private static UIVertex Vertex(float x, float y, float width, float bottom, float height)
    {
        return new UIVertex {position=new Vector3(x,y,0), color=new Color32(200,150,100,255),
            uv0=new Vector4(x/width,(y-bottom)/height,0,0),
            uv1=new Vector4((y-bottom)/height,x/width,1,1)};
    }
    private static void Quad(List<UIVertex> list, float left, float right, float bottom, float top,
        float width, float origin, float height)
    {
        var a=Vertex(left,bottom,width,origin,height); var b=Vertex(left,top,width,origin,height);
        var c=Vertex(right,top,width,origin,height); var d=Vertex(right,bottom,width,origin,height);
        list.AddRange(new[]{a,b,c,c,d,a});
    }
    private static VertexHelper Mesh(List<UIVertex> source)
    {var mesh=new VertexHelper(); mesh.AddUIVertexTriangleStream(source); return mesh;}

    private static void Test(float factor, bool sliced)
    {
        float width=70*factor, height=450*factor, bottom=-225*factor, cap=88*factor, extra=54*factor;
        var obj=new GameObject("NativeStrip",typeof(Image),typeof(Mask),typeof(VerticalLayoutGroup));
        var rect=(RectTransform)obj.transform; rect.sizeDelta=new Vector2(width,height);
        var image=obj.GetComponent<Image>(); var originalSprite=new Sprite(); image.sprite=originalSprite;
        var child=new GameObject("NativeButton"); child.transform.SetParent(rect,false);
        var childRect=(RectTransform)child.transform; childRect.anchoredPosition=new Vector2(35*factor,418*factor);
        var effect=obj.AddComponent<NavigationBackdrop>();
        var source=new List<UIVertex>();
        if (!sliced) Quad(source,0,width,bottom,bottom+height,width,bottom,height);
        else
        {
            float[] xs={0,10*factor,width-10*factor,width};
            float[] ys={bottom,bottom+25*factor,bottom+height-40*factor,bottom+height};
            for(int x=0;x<3;++x) for(int y=0;y<3;++y)
                Quad(source,xs[x],xs[x+1],ys[y],ys[y+1],width,bottom,height);
        }
        var mesh=Mesh(source);
        effect.Configure(extra,cap);
        effect.ModifyMesh(mesh);
        var actual=new List<UIVertex>(); mesh.GetUIVertexStream(actual);
        float min=float.MaxValue,max=float.MinValue,totalArea=0;
        foreach(var v in actual)
        {
            min=Math.Min(min,v.position.y); max=Math.Max(max,v.position.y);
            float oldY=bottom+v.uv0.y*height;
            if (oldY<=bottom+cap+0.001f) Near(v.position.y,oldY,"lower ornament retained");
            if (oldY>=bottom+height-cap-0.001f) Near(v.position.y,oldY+extra,"upper ornament translated rigidly");
            Near(v.position.x,v.uv0.x*width,"horizontal art remains unchanged");
            Near(v.uv1.x,v.uv0.y,"secondary texture coordinates preserved");
            Near(v.uv1.y,v.uv0.x,"rotated UV mapping preserved");
            Check(v.color.a==255 && v.color.r==200,"color and opacity retained");
            Check(v.position.x>=-0.001f && v.position.x<=width+0.001f,"no horizontal spill");
        }
        for(int i=0;i<actual.Count;i+=3)
        {
            var a=actual[i].position; var b=actual[i+1].position; var c=actual[i+2].position;
            float area=((b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x))*0.5f;
            Check(area<0,"triangle winding retained"); totalArea-=area;
        }
        Near(min,bottom,"bottom of strip fixed"); Near(max,bottom+height+extra,"one new slot added");
        Check(Math.Abs(totalArea-width*(height+extra))<0.1f,"continuous coverage without gaps or overlaps");
        Check(image.enabled && obj.GetComponent<Mask>().enabled,"native image and mask remain enabled");
        Check(image.sprite==originalSprite,"original sprite retained");
        Check(rect.childCount==1 && childRect.parent==rect,"layout hierarchy unchanged");
        Near(rect.sizeDelta.y,height,"layout dimensions unchanged");
        Near(childRect.anchoredPosition.y,418*factor,"native button unmoved");
        int dirty=image.dirtyCalls;
        effect.Configure(extra,cap); Check(image.dirtyCalls==dirty,"no rebuild each frame");
        effect.Configure(0,cap); var restored=Mesh(source); effect.ModifyMesh(restored);
        Check(restored.currentVertCount==source.Count,"disable extension restores source mesh");
        effect.Configure(extra,cap); var again=Mesh(source); effect.ModifyMesh(again);
        Check(again.currentVertCount==mesh.currentVertCount,"rebuild does not accumulate geometry");
    }
    private static int Main()
    {
        try
        {
            foreach(float factor in new[]{0.5f,1f,2f}) {Test(factor,false);Test(factor,true);}
            Console.WriteLine("PASS: "+checks+" backdrop geometry/ownership assertions (Unity test doubles).");
            return 0;
        }
        catch(Exception ex) {Console.Error.WriteLine("FAIL: "+ex.Message);return 1;}
    }
}
