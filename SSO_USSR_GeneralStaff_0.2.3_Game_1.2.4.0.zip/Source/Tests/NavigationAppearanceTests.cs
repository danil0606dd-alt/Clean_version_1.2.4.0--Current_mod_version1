using System;
using System.Reflection;
using System.Text;
using SsoUssr.GeneralStaff;
using UnityEngine;
using UnityEngine.UI;

// Executes the real NavigationAppearance source against a minimal scene graph.
// Tests ownership and lifecycle only, not Unity rendering or layout computation.
internal static class NavigationAppearanceTests
{
    private static int assertions;
    private static void Check(bool condition, string message)
    {
        if (!condition) throw new Exception(message);
        ++assertions;
    }

    private static string Snapshot(Transform node)
    {
        var result = new StringBuilder();
        var rect = (RectTransform)node;
        var image = node.GetComponent<Image>();
        result.Append(node.name).Append('|').Append(node.GetSiblingIndex()).Append('|')
            .Append(node.childCount).Append('|').Append(node.gameObject.activeSelf).Append('|')
            .Append(rect.anchorMin).Append('|').Append(rect.anchorMax).Append('|').Append(rect.pivot).Append('|')
            .Append(rect.sizeDelta).Append('|').Append(rect.anchoredPosition3D).Append('|').Append(rect.localScale)
            .Append('|').Append(image == null ? "no-image" : image.enabled + ":" + image.color + ":" + image.raycastTarget);
        foreach (Transform child in node) result.Append('\n').Append(Snapshot(child));
        return result.ToString();
    }

    private static void Lifecycle(NavigationAppearance view, string name)
    {
        typeof(NavigationAppearance).GetMethod(name, BindingFlags.Instance | BindingFlags.NonPublic)?.Invoke(view, null);
    }

    private static void Run(bool visibleBackground)
    {
        var scene = new GameObject("NativeCanvas", typeof(RectTransform), typeof(Canvas));
        ((RectTransform)scene.transform).sizeDelta = new Vector2(1920, 1080);
        var panel = new GameObject("NativePanel", typeof(RectTransform), typeof(Image), typeof(Mask), typeof(VerticalLayoutGroup));
        panel.transform.SetParent(scene.transform, false);
        ((RectTransform)panel.transform).sizeDelta = new Vector2(64, 464);
        var nativeBackground = panel.GetComponent<Image>();
        nativeBackground.sprite = new Sprite();
        nativeBackground.enabled = visibleBackground;
        RectTransform diplomacy = null;
        for (int i = 0; i < 8; ++i)
        {
            var button = new GameObject("SceneButton" + i, typeof(RectTransform), typeof(Image));
            button.transform.SetParent(panel.transform, false);
            var rect = (RectTransform)button.transform;
            rect.sizeDelta = new Vector2(44, 44);
            rect.anchoredPosition = new Vector2(0, 418 - 54 * i);
            button.GetComponent<Image>().sprite = new Sprite();
            button.GetComponent<Image>().material = new object();
            var glyph = new GameObject("Glyph", typeof(RectTransform), typeof(Image));
            glyph.transform.SetParent(rect, false);
            ((RectTransform)glyph.transform).sizeDelta = new Vector2(24, 24);
            if (i == 0) diplomacy = rect;
        }
        string initial = Snapshot(scene.transform);
        for (int cycle = 0; cycle < 3; ++cycle)
        {
            var owned = new GameObject("ModOverlay", typeof(RectTransform));
            var view = owned.AddComponent<NavigationAppearance>();
            Image disk = view.Build(diplomacy, new Sprite());
            Check(nativeBackground.enabled == visibleBackground, "Build changed the native panel Image.enabled (mask regression)");
            Check(panel.transform.childCount == 8, "Build inserted a decoration into the native button layout");
            Check(Snapshot(scene.transform) == initial, "Build changed the native scene graph");
            Check(disk.transform.IsChildOf(owned.transform), "The new button must belong to the mod overlay");
            var resize = typeof(NavigationAppearance).GetMethod("Resize");
            foreach (float scale in new[] { 0.71f, 1f, 2f })
            {
                // Supports the old signature too, so the test can expose 0.2.0.
                resize.Invoke(view, resize.GetParameters().Length == 3
                    ? new object[] {44 * scale, 44 * scale, 54 * scale}
                    : new object[] {44 * scale, 44 * scale});
                Check(Snapshot(scene.transform) == initial, "Resize changed native controls");
            }
            Lifecycle(view, "OnDisable");
            Check(Snapshot(scene.transform) == initial, "Closing/hiding changed the native panel");
            Lifecycle(view, "OnEnable");
            Check(Snapshot(scene.transform) == initial, "Showing changed the native panel");
            Lifecycle(view, "OnDestroy");
            UnityEngine.Object.Destroy(owned);
            Check(Snapshot(scene.transform) == initial, "Disposal changed the native panel");
        }
    }

    private static int Main()
    {
        try
        {
            Run(true);
            Run(false);
            Console.WriteLine("PASS: " + assertions + " native-panel ownership/lifecycle assertions.");
            return 0;
        }
        catch (Exception ex) { Console.Error.WriteLine("FAIL: " + ex.Message); return 1; }
    }
}
