// Test-only scene graph. Does not implement the Unity player, rendering, stencil
// masking or LayoutGroup algorithms. Never included in the actual mod DLL.
using System;
using System.Collections;
using System.Collections.Generic;

namespace UnityEngine
{
    public sealed class DisallowMultipleComponent : Attribute { }
    public class Object
    {
        public static void Destroy(Object value)
        {
            if (value is GameObject obj) obj.transform.SetParent(null, false);
        }
    }
    public class Component : Object
    {
        public GameObject gameObject;
        public Transform transform => gameObject.transform;
        public string name { get => gameObject.name; set => gameObject.name = value; }
        public T GetComponent<T>() where T : Component => gameObject.GetComponent<T>();
        public T GetComponentInParent<T>() where T : Component
        {
            for (Transform t = transform; t != null; t = t.parent)
                if (t.GetComponent<T>() is T found) return found;
            return null;
        }
    }
    public class Behaviour : Component { public bool enabled = true; }
    public class MonoBehaviour : Behaviour { }
    public class GameObject : Object
    {
        public string name;
        public int layer;
        public bool activeSelf = true;
        public bool activeInHierarchy => activeSelf && (transform.parent == null || transform.parent.gameObject.activeInHierarchy);
        public Transform transform;
        private readonly List<Component> components = new List<Component>();
        public GameObject(string name, params Type[] types)
        {
            this.name = name;
            transform = new RectTransform {gameObject = this};
            components.Add(transform);
            foreach (Type type in types) if (!typeof(Transform).IsAssignableFrom(type)) Add(type);
        }
        private Component Add(Type type)
        {
            var c = (Component)Activator.CreateInstance(type);
            c.gameObject = this;
            components.Add(c);
            return c;
        }
        public T AddComponent<T>() where T : Component => (T)Add(typeof(T));
        public T GetComponent<T>() where T : Component
        {
            foreach (Component c in components) if (c is T match) return match;
            return null;
        }
        public void SetActive(bool active) { activeSelf = active; }
    }
    public class Transform : Component, IEnumerable
    {
        public Transform parent;
        private readonly List<Transform> children = new List<Transform>();
        public int childCount => children.Count;
        public Vector3 localScale = Vector3.one;
        public Quaternion localRotation = Quaternion.identity;
        public Vector3 lossyScale => localScale;
        public void SetParent(Transform value, bool worldPositionStays)
        {
            parent?.children.Remove(this);
            parent = value;
            parent?.children.Add(this);
        }
        public void SetAsFirstSibling() { parent?.children.Remove(this); parent?.children.Insert(0, this); }
        public int GetSiblingIndex() => parent == null ? 0 : parent.children.IndexOf(this);
        public bool IsChildOf(Transform other)
        {
            for (Transform t = this; t != null; t = t.parent) if (t == other) return true;
            return false;
        }
        public Vector3 TransformPoint(Vector3 point) => point;
        public IEnumerator GetEnumerator() => children.GetEnumerator();
    }
    public class RectTransform : Transform
    {
        public Vector2 anchorMin, anchorMax, pivot, sizeDelta, offsetMin, offsetMax;
        public Vector3 anchoredPosition3D;
        public Vector2 anchoredPosition
        {
            get => new Vector2(anchoredPosition3D.x, anchoredPosition3D.y);
            set => anchoredPosition3D = new Vector3(value.x, value.y, 0);
        }
        public Rect rect => new Rect(sizeDelta.x, sizeDelta.y);
    }
    public struct Rect
    {
        public float width, height;
        public Rect(float width, float height) { this.width = width; this.height = height; }
        public Vector2 size => new Vector2(width, height);
    }
    public struct Vector2
    {
        public float x, y;
        public Vector2(float x, float y) { this.x = x; this.y = y; }
        public static Vector2 zero => new Vector2(0, 0);
        public static Vector2 one => new Vector2(1, 1);
        public float magnitude => (float)Math.Sqrt(x * x + y * y);
        public static Vector2 operator -(Vector2 a, Vector2 b) => new Vector2(a.x-b.x, a.y-b.y);
        public override string ToString() => x + "," + y;
    }
    public struct Vector3
    {
        public float x, y, z;
        public Vector3(float x, float y, float z) { this.x = x; this.y = y; this.z = z; }
        public static Vector3 zero => new Vector3(0, 0, 0);
        public static Vector3 one => new Vector3(1, 1, 1);
        public static Vector3 up => new Vector3(0, 1, 0);
        public static Vector3 LerpUnclamped(Vector3 a, Vector3 b, float t) =>
            new Vector3(a.x+(b.x-a.x)*t, a.y+(b.y-a.y)*t, a.z+(b.z-a.z)*t);
        public override string ToString() => x + "," + y + "," + z;
    }
    public struct Vector4
    {
        public float x,y,z,w;
        public Vector4(float x, float y, float z, float w) {this.x=x;this.y=y;this.z=z;this.w=w;}
        public static Vector4 LerpUnclamped(Vector4 a, Vector4 b, float t) =>
            new Vector4(a.x+(b.x-a.x)*t, a.y+(b.y-a.y)*t, a.z+(b.z-a.z)*t, a.w+(b.w-a.w)*t);
    }
    public struct Color32
    {
        public byte r,g,b,a;
        public Color32(byte r,byte g,byte b,byte a) {this.r=r;this.g=g;this.b=b;this.a=a;}
        public static Color32 Lerp(Color32 a, Color32 b, float t) => new Color32(
            (byte)(a.r+(b.r-a.r)*t),(byte)(a.g+(b.g-a.g)*t),(byte)(a.b+(b.b-a.b)*t),(byte)(a.a+(b.a-a.a)*t));
    }
    public struct UIVertex
    {
        public Vector3 position, normal;
        public Vector4 tangent, uv0, uv1, uv2, uv3;
        public Color32 color;
    }
    public struct Quaternion { public static Quaternion identity => new Quaternion(); }
    public struct Color
    {
        public float r,g,b,a;
        public Color(float r,float g,float b,float a = 1) {this.r=r;this.g=g;this.b=b;this.a=a;}
        public static Color clear => new Color(0,0,0,0);
        public static Color white => new Color(1,1,1);
        public override string ToString() => r + "," + g + "," + b + "," + a;
    }
    public static class Mathf
    {
        public static float Max(float a, float b) => Math.Max(a,b);
        public static float Min(float a, float b) => Math.Min(a,b);
        public static float Clamp01(float a) => Math.Max(0, Math.Min(1,a));
        public static float Abs(float value) => Math.Abs(value);
    }
    public class Sprite : Object { }
    public class Camera : Behaviour { }
    public enum RenderMode { ScreenSpaceOverlay, ScreenSpaceCamera }
    public class Canvas : Behaviour
    {
        public Canvas rootCanvas => this;
        public RenderMode renderMode;
        public Camera worldCamera;
    }
    public static class RectTransformUtility
    {
        public static Vector2 WorldToScreenPoint(Camera camera, Vector3 point) => new Vector2(point.x,point.y);
    }
}
namespace UnityEngine.UI
{
    public class Graphic : UnityEngine.Behaviour
    {
        public int dirtyCalls;
        public void SetVerticesDirty() { ++dirtyCalls; }
    }
    public class BaseMeshEffect : UnityEngine.Behaviour
    {
        protected Graphic graphic => GetComponent<Graphic>();
        public bool IsActive() => enabled && gameObject.activeInHierarchy;
        public virtual void ModifyMesh(VertexHelper mesh) { }
    }
    public sealed class VertexHelper
    {
        private readonly List<UnityEngine.UIVertex> vertices = new List<UnityEngine.UIVertex>();
        public int currentVertCount => vertices.Count;
        public void GetUIVertexStream(List<UnityEngine.UIVertex> output) { output.AddRange(vertices); }
        public void AddUIVertexTriangleStream(List<UnityEngine.UIVertex> input) { vertices.AddRange(input); }
        public void Clear() { vertices.Clear(); }
    }
    public class Image : Graphic
    {
        public UnityEngine.Sprite sprite;
        public int type, fillMethod, fillOrigin;
        public UnityEngine.Color color;
        public object material;
        public bool preserveAspect, fillCenter, fillClockwise, useSpriteMesh, raycastTarget;
        public float fillAmount, pixelsPerUnitMultiplier;
        public UnityEngine.RectTransform rectTransform => (UnityEngine.RectTransform)transform;
    }
    public class Mask : UnityEngine.Behaviour { }
    public class VerticalLayoutGroup : UnityEngine.Behaviour { }
}
namespace Backend.Managers
{
    public static class PopUpWindowManager
    {
        public static UnityEngine.Sprite GetCircleSprite() => new UnityEngine.Sprite();
    }
}
