using System;
using SsoUssr.GeneralStaff;

internal static class PlacementTests
{
    private static int assertions;
    private static void Equal(float actual, float expected, string name)
    {
        if (Math.Abs(actual - expected) > 0.01f)
            throw new Exception(name + ": expected " + expected + ", got " + actual);
        ++assertions;
    }
    private static void Main()
    {
        // Coordinates measured from the user's 1920x1080 screenshot, with the
        // screen-space origin converted from top left to Unity's bottom left.
        var diplomacy = new ScreenBox(1885, 418, 44, 44);
        var lower = new ScreenBox(1885, 364, 44, 44);
        var p = Placement.Above(diplomacy, new[] { diplomacy, lower });
        Equal(p.X, 1885, "same column");
        Equal(p.Y, 472, "one navigation slot above Diplomacy");
        Equal(p.Width, 44, "native width");
        Equal(p.Height, 44, "native height");

        // A differently scaled/positioned canvas must produce the same relative
        // placement. There is no fixed pixel coordinate or guessed screen corner.
        foreach (float scale in new[] { 0.7114583f, 1.3333333f, 2f })
        {
            var source = new ScreenBox(1885 * scale + 17, 418 * scale + 11, 44 * scale, 44 * scale);
            var neighbour = new ScreenBox(1885 * scale + 17, 364 * scale + 11, 44 * scale, 44 * scale);
            var result = Placement.Above(source, new[] { source, neighbour });
            Equal(result.X, source.X, "scaled column");
            Equal(result.Y, 472 * scale + 11, "scaled pitch");
            Equal(result.Width, 44 * scale, "scaled size");
        }

        // An unrelated panel, a same-position duplicate and buttons above the
        // reference must not alter the measured vertical navigation pitch.
        var noise = new[] { new ScreenBox(1000, 410, 44, 44), diplomacy,
            new ScreenBox(1885, 600, 44, 44), lower, new ScreenBox(1885, 310, 44, 44) };
        Equal(Placement.Above(diplomacy, noise).Y, 472, "ignore unrelated controls");
        Equal(Placement.Above(diplomacy, new ScreenBox[0]).Y, 473, "single-button fallback");
        Equal(Placement.Above(diplomacy, new[] { new ScreenBox(1885, 100, 44, 44) }).Y,
            473, "reject implausible pitch");
        var crowded = Placement.Above(diplomacy, new[] { new ScreenBox(1885, 390, 44, 44) });
        if (crowded.Y - diplomacy.Y <= diplomacy.Height) throw new Exception("Buttons overlap");
        ++assertions;
        Console.WriteLine("PASS: " + assertions + " placement assertions.");
    }
}
