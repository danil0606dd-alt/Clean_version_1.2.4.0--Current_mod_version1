using System;
using SsoUssr.GeneralStaff;

internal static class NavigationContinuityTests
{
    private static int assertions;
    private static void Check(bool condition, string label)
    {
        if (!condition) throw new Exception(label);
        ++assertions;
    }
    private static void Near(float actual, float expected, string label)
    {
        Check(Math.Abs(actual - expected) < 0.01f, label + ": " + actual + " != " + expected);
    }

    private static ScreenBox Project(ScreenBox element, ScreenBox canvas, ScreenBox viewport)
    {
        ScreenBox result;
        Check(Placement.TryCanvasToScreen(element, canvas, viewport, out result), "valid canvas projection");
        return result;
    }

    private static void Projection()
    {
        var canvas = new ScreenBox(0, 0, 1920, 1080);
        var viewport = new ScreenBox(960, 540, 1920, 1080);
        var source = new ScreenBox(925, -122, 44, 44);
        var button = Project(source, canvas, viewport);
        Near(button.X, 1885, "screenshot x");
        Near(button.Y, 418, "screenshot y");
        Near(button.Width, 44, "screenshot width");
        var neighbour = Project(new ScreenBox(925, -176, 44, 44), canvas, viewport);
        Near(Placement.Above(button, new[] { button, neighbour }).Y, 472, "slot above globe");

        // Canvas pivot/coordinate origin must not change the final pixel position.
        var bottomLeft = Project(new ScreenBox(1885, 418, 44, 44), viewport, viewport);
        Near(bottomLeft.X, button.X, "bottom-left pivot x");
        Near(bottomLeft.Y, button.Y, "bottom-left pivot y");
        foreach (float offset in new[] { -5000f, 0f, 13000f })
        {
            var translated = Project(new ScreenBox(source.X + offset, source.Y - offset, 44, 44),
                new ScreenBox(offset, -offset, 1920, 1080), viewport);
            Near(translated.X, button.X, "canvas origin translation x");
            Near(translated.Y, button.Y, "canvas origin translation y");
        }
        var small = Project(source, canvas, new ScreenBox(640, 360, 1280, 720));
        Near(small.X, 1885 * 2f / 3, "1280x720 x");
        Near(small.Height, 44 * 2f / 3, "1280x720 height");
        var offsetView = Project(source, canvas, new ScreenBox(500, 310, 960, 540));
        Near(offsetView.X, 962.5f, "viewport offset x");
        Near(offsetView.Y, 249, "viewport offset y");
        ScreenBox ignored;
        Check(!Placement.TryCanvasToScreen(source, new ScreenBox(), viewport, out ignored), "reject uninitialized canvas");
        Check(!Placement.TryCanvasToScreen(source, canvas, new ScreenBox(), out ignored), "reject missing viewport");
        Check(!Placement.TryCanvasToScreen(new ScreenBox(float.NaN, 0, 44, 44), canvas, viewport, out ignored), "reject NaN");
    }

    private static void Transitions()
    {
        const int map = 10, statistics = 20, economy = 30, menu = 99;
        int[] destinations = {map, statistics, economy};
        var session = new NavigationSession();
        Check(!session.Visible(false, true), "no button before a gameplay panel exists");
        session.Bind(map, destinations);
        Check(!session.Visible(false, true), "do not display unplaced button");
        session.Placed();
        Check(session.Visible(false, true), "placed button visible");
        Check(session.CanOpen(true, false), "can open while ready");
        Check(session.Visible(true, true), "star remains available to close its section");
        Check(session.Visible(true, false), "own input lock must not hide the close control");
        Check(!session.Visible(false, false), "ordinary blocking dialogs respected");
        Check(!session.CanOpen(true, true), "native hotkey lock respected");

        foreach (int target in new[] {statistics, economy, economy, map})
        {
            session.BeginTransition(target);
            Check(session.Visible(false, false), "button survives scene input prohibition");
            Check(!session.CanOpen(false, false), "cannot click during load");
            Check(!session.HasBinding, "old scene binding released");
            session.FinishTransition(true);
            Check(session.InTransition, "wait while engine loads");
            session.SceneLoaded(target);
            Check(session.Visible(false, false), "button survives scene destruction and sceneLoaded");
            session.FinishTransition(false);
            Check(session.InTransition, "wait for NavPanel Start/Repaint even if loading has ended");
            session.Bind(target, destinations);
            Check(session.Visible(false, false), "rebinding does not blink");
            Check(!session.CanOpen(true, false), "rebinding does not unlock early");
            session.FinishTransition(true);
            Check(!session.CanOpen(true, false), "engine must finish too");
            session.FinishTransition(false);
            Check(session.CanOpen(true, false), "click restored when fully loaded");
        }
        session.BeginTransition(menu);
        Check(!session.Visible(false, false), "hide when leaving gameplay");
        session.SceneLoaded(menu);
        session.FinishTransition(false);
        Check(!session.Visible(false, true), "no stray button in main menu");
        Check(!session.CanOpen(true, false), "W blocked in main menu");
        session.Bind(map, destinations);
        Check(session.Visible(false, true), "reuse button on next game");
        // Also tolerate a scene loaded outside the game's LoadScene wrapper.
        session.SceneLoaded(statistics);
        Check(session.Visible(false, false), "direct known-scene load retains button");
        Check(!session.CanOpen(true, false), "direct load awaits binding");
        session.Bind(statistics, destinations);
        session.FinishTransition(false);
        Check(session.CanOpen(true, false), "direct load completes");
    }

    private static int Main()
    {
        try
        {
            Projection();
            Transitions();
            Console.WriteLine("PASS: " + assertions + " projection/transition assertions.");
            return 0;
        }
        catch (Exception ex) { Console.Error.WriteLine("FAIL: " + ex.Message); return 1; }
    }
}
