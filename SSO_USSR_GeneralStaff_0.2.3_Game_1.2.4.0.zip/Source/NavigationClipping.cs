using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace SsoUssr.GeneralStaff
{
    // Some UI prefabs use a rectangular clip in addition to the Image stencil.
    // Expand only its top clipping edge if it would cut off the new cap. Layout,
    // the other three clip edges and the enabled state are never changed.
    internal sealed class NavigationClipping
    {
        private sealed class Lease
        {
            public RectMask2D Mask;
            public float Added;
        }
        private readonly List<Lease> leases = new List<Lease>();

        public void Bind(Image image)
        {
            Restore();
            foreach (RectMask2D mask in image.GetComponentsInParent<RectMask2D>(true))
                leases.Add(new Lease { Mask = mask });
        }

        public void Update(bool extend, float screenTop)
        {
            foreach (Lease lease in leases)
            {
                RectMask2D mask = lease.Mask;
                if (mask == null) continue;
                Vector4 padding = mask.padding;
                // Remove only our prior adjustment, preserving other changes.
                float originalTop = padding.w + lease.Added;
                float added = 0;
                Canvas canvas = mask.GetComponentInParent<Canvas>();
                Canvas root = canvas != null ? canvas.rootCanvas : null;
                RectTransform rootRect = root != null ? root.transform as RectTransform : null;
                if (extend && mask.enabled && rootRect != null && root.pixelRect.height > 0)
                {
                    float canvasTop = rootRect.rect.yMin + (screenTop - root.pixelRect.yMin) *
                        rootRect.rect.height / root.pixelRect.height;
                    added = Mathf.Max(0, canvasTop - mask.canvasRect.yMax + originalTop);
                }
                float updated = originalTop - added;
                if (Mathf.Abs(padding.w - updated) > 0.001f)
                {
                    padding.w = updated;
                    mask.padding = padding;
                }
                lease.Added = added;
            }
        }

        public void Restore()
        {
            Update(false, 0);
            leases.Clear();
        }
    }
}
