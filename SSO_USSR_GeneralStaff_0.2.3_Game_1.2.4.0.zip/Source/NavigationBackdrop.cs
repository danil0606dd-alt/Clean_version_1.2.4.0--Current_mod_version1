using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace SsoUssr.GeneralStaff
{
    // Changes only the existing Image's rendered mesh. No extra layout child,
    // no disabled Image/mask, no changed RectTransform, material or sprite.
    // Both end caps are rigid; the original texture fills the longer middle.
    [DisallowMultipleComponent]
    public sealed class NavigationBackdrop : BaseMeshEffect
    {
        private float extension, capHeight;
        private readonly List<UIVertex> input = new List<UIVertex>();
        private readonly List<UIVertex> output = new List<UIVertex>();
        private readonly List<UIVertex> polygon = new List<UIVertex>(8);
        private readonly List<UIVertex> scratch = new List<UIVertex>(8);

        public void Configure(float height, float cap)
        {
            height = Mathf.Max(0, height);
            cap = Mathf.Max(0, cap);
            if (Mathf.Abs(extension - height) < 0.001f && Mathf.Abs(capHeight - cap) < 0.001f) return;
            extension = height;
            capHeight = cap;
            if (graphic != null) graphic.SetVerticesDirty();
        }

        public override void ModifyMesh(VertexHelper mesh)
        {
            if (!IsActive() || extension <= 0 || mesh.currentVertCount == 0) return;
            input.Clear(); output.Clear();
            mesh.GetUIVertexStream(input);
            float min = float.MaxValue, max = float.MinValue;
            foreach (UIVertex vertex in input)
            {
                min = Mathf.Min(min, vertex.position.y);
                max = Mathf.Max(max, vertex.position.y);
            }
            if (max - min < 1) return;
            float cap = Mathf.Min(capHeight, (max - min) * 0.4f);
            float lower = min + cap, upper = max - cap;
            for (int i = 0; i + 2 < input.Count; i += 3)
            {
                // Split triangles at both cap boundaries before moving them.
                // A four-vertex Simple Image therefore retains its curved caps
                // just as a nine-sliced sprite does. UVs and colors are retained.
                for (int band = 0; band < 3; ++band)
                {
                    polygon.Clear();
                    polygon.Add(input[i]); polygon.Add(input[i + 1]); polygon.Add(input[i + 2]);
                    if (band > 0) Clip(band == 1 ? lower : upper, true);
                    if (band < 2) Clip(band == 0 ? lower : upper, false);
                    for (int j = 1; j + 1 < polygon.Count; ++j)
                    {
                        UIVertex a = Extend(polygon[0], lower, upper);
                        UIVertex b = Extend(polygon[j], lower, upper);
                        UIVertex c = Extend(polygon[j + 1], lower, upper);
                        float area = (b.position.x - a.position.x) * (c.position.y - a.position.y) -
                            (b.position.y - a.position.y) * (c.position.x - a.position.x);
                        if (Mathf.Abs(area) < 0.0001f) continue;
                        output.Add(a); output.Add(b); output.Add(c);
                    }
                }
            }
            // An unexpected mesh should leave the native panel intact.
            if (output.Count == 0) return;
            mesh.Clear();
            mesh.AddUIVertexTriangleStream(output);
        }

        private UIVertex Extend(UIVertex vertex, float lower, float upper)
        {
            vertex.position.y += extension * Mathf.Clamp01((vertex.position.y - lower) / (upper - lower));
            return vertex;
        }

        private void Clip(float boundary, bool above)
        {
            if (polygon.Count == 0) return;
            scratch.Clear();
            UIVertex previous = polygon[polygon.Count - 1];
            bool previousInside = above ? previous.position.y >= boundary : previous.position.y <= boundary;
            foreach (UIVertex current in polygon)
            {
                bool inside = above ? current.position.y >= boundary : current.position.y <= boundary;
                if (inside != previousInside)
                    scratch.Add(Interpolate(previous, current,
                        (boundary - previous.position.y) / (current.position.y - previous.position.y)));
                if (inside) scratch.Add(current);
                previous = current;
                previousInside = inside;
            }
            polygon.Clear(); polygon.AddRange(scratch);
        }

        private static UIVertex Interpolate(UIVertex a, UIVertex b, float t)
        {
            UIVertex result = a;
            result.position = Vector3.LerpUnclamped(a.position, b.position, t);
            result.color = Color32.Lerp(a.color, b.color, t);
            result.uv0 = Vector4.LerpUnclamped(a.uv0, b.uv0, t);
            result.uv1 = Vector4.LerpUnclamped(a.uv1, b.uv1, t);
            result.uv2 = Vector4.LerpUnclamped(a.uv2, b.uv2, t);
            result.uv3 = Vector4.LerpUnclamped(a.uv3, b.uv3, t);
            return result;
        }
    }
}
